import os
import json

def merge_json_dicts(directory):
    merged_dict = {}
    
    # Elenco tutti i file JSON nella directory specificata
    for filename in os.listdir(directory):
        if filename.endswith('.json'):
            filepath = os.path.join(directory, filename)
            with open(filepath, 'r', encoding='utf-8') as file:
                data = json.load(file)
                # Unisci i dizionari verificando la presenza di duplicati
                merged_dict.update(data)
    
    # Ordina il dizionario per valore (URL)
    sorted_dict = dict(sorted(merged_dict.items(), key=lambda item: item[1]))
    
    # Salva il dizionario unito e ordinato in un nuovo file JSON
    output_filepath = os.path.join(directory, 'superlink.json')
    with open(output_filepath, 'w', encoding='utf-8') as outfile:
        json.dump(sorted_dict, outfile, ensure_ascii=False, indent=4)
    
    return sorted_dict

# Usa la funzione per unire i dizionari dalla cartella 'resources'



with open('resources/links.json', 'r', encoding='utf-8') as file:
                data = json.load(file)

for txt, link in data.items():
    if 